# 🔍 Machine Learning Anomaly Detection for Power Grid Faults

> **A beginner-friendly explanation of Isolation Forest anomaly detection in electrical power systems**

## 📋 Table of Contents
- [Overview](#overview)
- [Key Concepts](#key-concepts)
- [The Four Approaches](#the-four-approaches)
- [Understanding the Output](#understanding-the-output)
- [Code Structure](#code-structure)
- [Real-World Impact](#real-world-impact)
- [Next Steps](#next-steps)

## 🎯 Overview

Imagine you work for an electrical company and you have thousands of records of power outages (faults). Most outages are normal - maybe a tree fell on a power line during a storm. But some outages are **weird** - they might last much longer than expected, happen at strange times, or occur in unusual patterns.

This code uses a machine learning technique called **Isolation Forest** to automatically find these weird/unusual outages so engineers can investigate them further.

### 🎯 Goals
- ✅ Automatically identify unusual power outages
- ✅ Help engineers focus on potentially serious problems  
- ✅ Prevent major grid failures through early detection
- ✅ Improve overall power system reliability

## 🧠 Key Concepts

### 🎯 Anomaly Detection
- **Normal data**: Most power outages that follow expected patterns
- **Anomalies**: Unusual outages that don't fit the normal pattern
- **Analogy**: Like a teacher grading tests - most students get normal scores, but a few get surprisingly high or low scores that stand out

### 🌳 Isolation Forest
- A machine learning algorithm that finds outliers
- **How it works**: Asks "How easy is it to separate this data point from all the others?"
- **Normal points**: Hard to isolate (mixed in with lots of similar points)
- **Weird points**: Easy to isolate (stick out from the crowd)

### 📊 Features (Input Variables)
The algorithm analyzes these characteristics of each power outage:

| Feature | Description | Example |
|---------|-------------|---------|
| **Duration** | How long the outage lasted | 2.5 hours |
| **Reliability Index** | How reliable that circuit normally is | 0.85 (scale 0-1) |
| **Time Info** | Hour, day of week, month | Tuesday 3 AM |
| **Location** | Which electrical circuit failed | Circuit ABC-123 |
| **Cause** | What caused the outage | Tree branch |

## 🔬 The Four Approaches

### 🎯 Approach 1: Multi-Contamination Analysis

**What it does**: Tests different "contamination rates" to see how many anomalies to look for.

**Contamination rate**: The percentage of data you expect to be anomalies
- `5%` = "I think 5% of outages are weird"
- `25%` = "I think 25% of outages are weird"

**📊 Sample Results**:
```
Contamination 10%: 39 anomalies (4.7%)
Duration difference: +0.113 hours
Reliability difference: +0.005
```

**Translation**:
- ✅ Found 39 weird outages (4.7% of test data)
- ⏱️ Weird outages lasted **7 minutes longer** than normal
- 📉 Happened on circuits **0.005 points less reliable**

> **Why 10% was optimal**: Found the biggest difference in outage duration

---

### 🏗️ Approach 2: Circuit-Specific Analysis

**What it does**: Analyzes each electrical circuit separately instead of all together.

**Why this matters**: Different circuits have different "normal" patterns
- Storm-prone area circuit: Normally longer outages
- Stable area circuit: Normally shorter outages

**📊 Sample Output**:
```
Circuit ABC-123:
  Total faults: 85
  Anomalies: 8 (9.4%)
  Avg duration (anomaly): 2.456h
  Avg duration (normal): 1.123h
```

**Translation**: Circuit ABC-123 had 8 weird outages lasting **twice as long** as normal!

---

### ⏰ Approach 3: Temporal Pattern Analysis

**What it does**: Finds outages happening at weird times or following strange patterns.

**Time periods**:
| Period | Hours | Expected Pattern |
|--------|-------|-----------------|
| 🌙 Night | 12 AM - 6 AM | Usually quick fixes |
| 🌅 Morning | 6 AM - 12 PM | Higher activity |
| ☀️ Afternoon | 12 PM - 6 PM | Peak demand issues |
| 🌆 Evening | 6 PM - 12 AM | Equipment strain |

**Example**: A 5-hour outage at 3 AM is suspicious (normally quick at night)!

---

### 🤝 Approach 4: Ensemble Method

**What it does**: Uses 3 different models and combines their votes.

**Why multiple models**: Like getting second opinions from multiple doctors

**Majority vote system**:
- Model 1: "This is weird" ✅
- Model 2: "This is weird" ✅  
- Model 3: "This is normal" ❌
- **Result**: 2/3 vote = ANOMALY

**Benefits**: More reliable detection, fewer false alarms

## 📈 Understanding the Output

### 🔢 Key Metrics Explained

| Metric | Meaning | Example | Interpretation |
|--------|---------|---------|----------------|
| **Duration difference** | How much longer/shorter anomalous outages last | `+0.113 hours` | Weird outages last ~7 minutes longer |
| **Reliability difference** | Reliability gap between normal and weird | `+0.005` | Weird outages happen on less reliable circuits |
| **Percentage** | What % of data was flagged as anomalous | `4.7%` | About 1 in 20 outages is suspicious |
| **Anomaly score** | How "weird" something is (negative = weirder) | `-0.45` | More negative = more suspicious |

### 📊 Sample Results Breakdown

```bash
Optimal contamination rate: 10%
This finds anomalies with +0.113 hours duration difference
```

**What this means**:
- ✅ Best setting finds outages lasting 7 extra minutes
- 🎯 This setting balances finding real problems vs false alarms
- 📋 Engineers should investigate these longer-duration anomalies first

### 🚨 Typical Anomaly Characteristics

**Anomalous outages tend to be**:
- ⏱️ **Longer duration**: Last significantly more time than expected
- 📍 **Specific locations**: Happen on less reliable circuits  
- 🕐 **Odd timing**: Occur at unusual hours or days
- 🔧 **Unusual causes**: Triggered by rare or concerning events

## 🌍 Real-World Impact

### 🔧 What Engineers Do Next
1. **🔍 Investigate flagged outages**: Examine the specific outages marked as anomalous
2. **🔍 Root cause analysis**: Understand WHY these outages were different
3. **🛠️ Preventive action**: Fix underlying issues to prevent similar problems
4. **📈 Model improvement**: Use findings to enhance detection accuracy

### 💡 Benefits of Anomaly Detection

| Benefit | Impact | Example |
|---------|---------|---------|
| **🚨 Prevent failures** | Catch problems before they become disasters | Detect transformer overheating before explosion |
| **💰 Save money** | Early fixes cost less than emergency repairs | $1K fix vs $100K replacement |
| **⚡ Improve reliability** | Fewer unexpected outages for customers | 99.9% uptime instead of 99.5% |
| **📊 Better planning** | Understand system weaknesses | Schedule maintenance before peak season |

### 🏢 Business Value
- **Regulatory compliance**: Meet grid reliability standards
- **Customer satisfaction**: Fewer surprise power outages  
- **Operational efficiency**: Focus resources on real problems
- **Risk management**: Prevent catastrophic grid failures

### 🔒 Security Guard Analogy

Think of this system like a security guard at a building:

| Security Guard | Anomaly Detection |
|----------------|-------------------|
| 👥 **Normal people** | Regular power outages |
| 🚨 **Suspicious person** | Unusual outage patterns |
| 🧠 **Learns normal patterns** | Isolation Forest training |
| 🚩 **Flags weird behavior** | Anomaly alerts |
| 🔍 **Investigation follows** | Engineer analysis |
| ✅ **Prevents problems** | Grid failure prevention |

## Simple Analogy

Think of this like a security guard at a building:
- Most people who enter are normal (employees, visitors, deliveries)
- But occasionally someone suspicious shows up (wrong clothes, nervous behavior, unusual timing)
- The guard (Isolation Forest) learns what "normal" looks like
- When someone weird shows up, the guard flags them for investigation
- Sometimes it's nothing, but sometimes it prevents a real problem

The code is doing the same thing, but for power outages instead of people!